<?php
ini_set('max_execution_time', 0);

if(isset($_GET['btndecodeVal']) && $_GET['btndecodeVal'] == 'decodeVal' ){
 /* exec("C:\xampp\htdocs\Site\test-app\haker-contest\ffmpeg\bin\ffmpeg -h C:\xampp\htdocs\Site\test-app\haker-contest\input\test.avi  C:\xampp\htdocs\Site\test-app\haker-contest\output\380831.mp4");*/
 $var1 = isset($_GET['inputfileName'])?$_GET['inputfileName']:null;
 if($var1!= null){
	$var2 = strstr($var1,'.',true);
	//$bat_file = "batExe.bat ".escapeshellarg($var1);	
	$bat_file = "batExe.bat ".$var1;
    exec($bat_file);
 }else{
	echo 'File not upload or selected'.$var1."\n";
 }
}else{
	if(isset($_FILES['fileData'])){
	  $file_name = $_FILES['fileData']['name'];
	  $file_tmp =$_FILES['fileData']['tmp_name'];
	  move_uploaded_file($file_tmp, "input/".$file_name);
	  $message = "Success &f=".base64_encode($file_name);
	}else{
	 // $values = exec("START fileupload.bat");
	  $message = "File not valid";
	}
 header("location: ../haker-contest/?q=".$message);
}
