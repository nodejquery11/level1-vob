<?php
  $decodeVal = (isset($_GET['f']))? base64_decode($_GET['f']):null;
?>
<!doctype html>
<html>
 <head>
  <title> Media Conversion </title>
   <!--script type="text/javascript" src="jquery-1.12.0.min.js" ></script-->
   <link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
   <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
   <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    
  <script>
    $(document).ready(function(){		
		$("#btndecode").click(function(){
		  $.get("businessLogic.php",{btndecodeVal:"decodeVal", inputfileName:$("#hidVal").val()}, function(data){
		    //alert(data);
		  });
		});	
	});
    
   </script>

  </head>

 <body>
 <div id="bodyfield">
  <form name="conversion" id="conversion" method="post" enctype="multipart/form-data" action="businessLogic.php">
	<div> <input type="file" name="fileData" id="fileData" value="">
		<input type="submit" name="fileSubmit" id="fileSubmit" value="upload">
	</div>   
  </form>
  <p>
	<input type="button" name="btndecode" id="btndecode" value="Decode"> <?php echo  $decodeVal;?>
	<input type="hidden" id="hidVal" name="hidVal" value="<?php echo $decodeVal;?>">
  </p>
 </div>
 </body>
</html>
